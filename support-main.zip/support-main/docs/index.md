---
sidebar_position: 1
sidebar_title: intro
sidebar_label: Introduction
---

# 👋 Welcome!

:::danger[ERRORS]

Notice any inaccurate information on this website? Contact avnemone!

:::


🛍️ BloxStreet Corporation is the most prominent store-based establishment on the Roblox platform, dedicated to providing a lifelike and interactive shopping experience for every player. Our committed staff work tirelessly to ensure that each guest leaves satisfied after exploring our various store departments, including the meticulously designed cafe and advanced registers. BloxStreet Corporation is currently owned by PostlyTiked, but it is managed by the entire Senior High Rank team.

🔎 This support site contains guidelines, frequently asked questions, and other articles that can answer your questions.
- To get started, select a topic from the menu.
